// Copyright (c) 2018, Void P34r 
// Source Code

part of syncore;

/// A simple model for holding information about each of our items
class CoreItem {
  final String id;
  String title;
  bool completed;

  CoreItem({
    @required this.id,
    @required this.title,
    this.completed = false,
  })  : assert(id != null && id.isNotEmpty),
        assert(title != null && title.isNotEmpty),
        assert(completed != null);

  CoreItem.fromMap(Map<String, dynamic> data)
      : this(id: data['id'], title: data['title'], completed: data['completed'] ?? false);

  Map<String, dynamic> toMap() => {
        'id': this.id,
        'title': this.title,
        'completed': this.completed,
      };
}
