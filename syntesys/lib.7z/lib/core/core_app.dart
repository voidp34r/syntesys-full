// Copyright (c) 2018, Void P34r 
// Source Code

library syncore;

import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:meta/meta.dart';



import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_analytics/observer.dart';

import 'pages/tabs_page.dart';

part 'pages/splash_core_page.dart';
part 'pages/core_list.dart';
part 'models/core_item.dart';
part 'services/core_storage.dart';
part 'util/core_authentication.dart';
part 'widgets/core_loading_indicator.dart';
part 'widgets/core_header.dart';
part 'widgets/core_widget.dart';

// Login
part 'pages/login_page.dart';

class CoreApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Flutter • SynCore',
      debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        fontFamily: 'Helvetica Neue',
        primarySwatch: Colors.blueGrey,
      ),
      home: new LoginPage(),
      routes: <String, WidgetBuilder>{
        // '/todos': (BuildContext context) => new TodoList(),
        '/cores': (BuildContext context) => new CoreList(),
      },
    );
  }
}
