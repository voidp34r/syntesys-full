// Copyright (c) 2018, Void P34r 
// Source Code

part of syncore;

/// The filter values for which kind of filter tasks we will show
enum TypeCoreFilter {
  ALL,
  ACTIVE,
  COMPLETED,
}

class CoreList extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new CoreListState();
}

/// The bulk of the app's "smarts" are in this class
class CoreListState extends State<CoreList> {
  TypeCoreFilter typeCoreFilter;
  List<CoreItem> cores;

  /// List of Cores that are disabled in the UI while async operations are performed
  Set<String> disabledCores;

  StreamSubscription<QuerySnapshot> coreSub;
  CoreStorage coreStorage;
  FirebaseUser user;

  @override
  void initState() {
    super.initState();
    typeCoreFilter = TypeCoreFilter.ALL;
    cores = [];
    disabledCores = new Set();

    _auth.currentUser().then((FirebaseUser user) {
      if (user == null) {
        Navigator.of(context).pushReplacementNamed('/');
      } else {
        coreStorage = new CoreStorage.forUser(user: user);
        coreSub?.cancel();
        coreSub = coreStorage.list().listen((QuerySnapshot snapshot) {
          final List<CoreItem> cores = snapshot.documents.map(CoreStorage.fromDocument).toList(growable: false);
          setState(() {
            this.cores = cores;
          });
        });

        setState(() {
          this.user = user;
        });
      }
    });
  }

  @override
  void dispose() {
    coreSub?.cancel();
    super.dispose();
  }

  void setFilter(TypeCoreFilter filter) {
    setState(() {
      typeCoreFilter = filter;
    });
  }

  Widget buildToggleButton(TypeCoreFilter type, String text) {
    final bool enabled = type == typeCoreFilter;

    Widget button = new MaterialButton(
      key: new Key('filter-button-${text.toLowerCase()}'),
      textColor: enabled ? Colors.black : Colors.grey,
      child: new Text(text),
      onPressed: () => setFilter(type),
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      minWidth: 0.0,
    );

    if (enabled) {
      button = new Container(
        decoration: new BoxDecoration(
          border: new Border.all(),
          borderRadius: new BorderRadius.circular(3.0),
        ),
        child: button,
      );
    }

    return button;
  }

  Widget buildContent(int remainingActive) {
    if (user == null) {
      return new LoadingCoreIndicator();
    } else {
      // Apply our filter. If no filter just copy list, otherwise check the completed status
      // This is done at build time to simply our state and what we must keep track of
      final bool onlyActive = typeCoreFilter == TypeCoreFilter.ACTIVE;
      final List<CoreItem> visibleCores =
          typeCoreFilter == TypeCoreFilter.ALL ? cores : cores.where((t) => t.completed != onlyActive).toList(growable: false);

      final bool allCompleted = cores.isNotEmpty && remainingActive == 0;

      return new Column(
        children: <Widget>[
          new CoreHeaderWidget(
            key: new Key('core-header'),
            showToggleAll: cores.length > 0,
            toggleAllActive: allCompleted,
            onChangeToggleAll: () {
              this._toggleAll(!allCompleted);
            },
            onAddCore: this._createCore,
          ),
          new Expanded(
            flex: 2,
            child: new ListView.builder(
              key: const Key('core-list'),
              itemCount: visibleCores.length,
              itemBuilder: _buildCoreItem(visibleCores),
            ),
          ),
        ],
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Number of remaining tasks to complete
    final int remainingActive = cores.where((t) => !t.completed).length;

    final ThemeData themeData = Theme.of(context);

    return new Scaffold(
      appBar: new AppBar(
        title: const Text('Cores'),
      ),
      drawer: new Drawer(
        child: new ListView(
          primary: false,
          children: <Widget>[
            new DrawerHeader(
              child: new Center(
                child: new Text(
                  "Core MVC",
                  style: themeData.textTheme.title,
                ),
              ),
            ),
            new ListTile(
              title: const Text('Logout', textAlign: TextAlign.right),
              trailing: const Icon(Icons.exit_to_app),
              onTap: () async {
                await signOutWithGoogle();
                Navigator.of(context).pushReplacementNamed('/');
              },
            ),
          ],
        ),
      ),
      body: buildContent(remainingActive),
      bottomNavigationBar: new Padding(
        padding: const EdgeInsets.all(10.0),
        child: new Stack(
          fit: StackFit.loose,
          alignment: AlignmentDirectional.centerStart,
          children: <Widget>[
            new Text('$remainingActive item${remainingActive == 1 ? '' : 's'} left'),
            new Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                buildToggleButton(TypeCoreFilter.ALL, 'All'),
                buildToggleButton(TypeCoreFilter.ACTIVE, 'Active'),
                buildToggleButton(TypeCoreFilter.COMPLETED, 'Completed'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Method to create the widget builder for the cores that are passed in
  /// This allows us to have a separate function, to keep the code clean, while still allowing us to calculate the
  /// result of the filters are build-time.
  IndexedWidgetBuilder _buildCoreItem(List<CoreItem> cores) {
    return (BuildContext context, int idx) {
      final CoreItem core = cores[idx];
      return new CoreWidget(
        key: new Key('core-${core.id}'),
        core: core,
        disabled: disabledCores.contains(core.id),
        onToggle: (completed) {
          this._toggleCore(core, completed);
        },
        onTitleChanged: (newTitle) {
          this._editCore(core, newTitle);
        },
        onDelete: () {
          this._deleteCore(core);
        },
      );
    };
  }

  void _disableCore(CoreItem core) {
    setState(() {
      disabledCores.add(core.id);
    });
  }

  void _enabledCore(CoreItem core) {
    setState(() {
      disabledCores.remove(core.id);
    });
  }

  void _toggleAll(bool toggled) {
    cores.forEach((t) => this._toggleCore(t, toggled));
  }

  void _createCore(String title) {
    coreStorage.create(title);
  }

  void _deleteCore(CoreItem core) {
    this._disableCore(core);
    coreStorage.delete(core.id).catchError((_) {
      this._enabledCore(core);
    });
  }

  void _toggleCore(CoreItem core, bool completed) {
    this._disableCore(core);
    core.completed = completed;
    coreStorage.update(core).whenComplete(() {
      this._enabledCore(core);
    });
  }

  void _editCore(CoreItem core, String newTitle) {
    this._disableCore(core);
    core.title = newTitle;
    coreStorage.update(core).whenComplete(() {
      this._enabledCore(core);
    });
  }
}
