import 'package:flutter/material.dart';
import 'pre_model.dart';

class PreDetailPage extends StatelessWidget {

  final Pre pre;

  PreDetailPage(this.pre);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        color: const Color(0xFF736AB7),
        constraints: new BoxConstraints.expand(),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Text(pre.name),
            new Hero(tag: "planet-hero-${pre.id}",
              child: new Image.asset(
                  pre.image,
                  width: 96.0,
                  height: 96.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}