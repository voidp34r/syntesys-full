import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';


class Auth extends StatefulWidget {
  final name = 'auth';
  final String title = 'Auth';
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = new GoogleSignIn();

  Future<FirebaseUser> signInWithGoogle() async {
    // Attempt to get the currently authenticated user
    GoogleSignInAccount currentUser = _googleSignIn.currentUser;
    if (currentUser == null) {
      // Attempt to sign in without user interaction
      currentUser = await _googleSignIn.signInSilently();
    }
    if (currentUser == null) {
      // Force the user to interactively sign in
      currentUser = await _googleSignIn.signIn();
    }
    final GoogleSignInAuthentication auth = await currentUser.authentication;
    // Authenticate with fire
    final FirebaseUser user = await _auth.signInWithGoogle(
      idToken: auth.idToken,
      accessToken: auth.accessToken,
    );
    assert(user != null);
    assert(!user.isAnonymous);
    return user;
  }

  Future<Null> signOutWithGoogle() async {
    // Sign out with fire
    await _auth.signOut();
    // Sign out with google
    await _googleSignIn.signOut();
  }


  @override
  State createState() => new _AuthPageState();
}

class _AuthPageState extends State<Auth> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = new GoogleSignIn();

  Future<FirebaseUser> signInWithGoogle() async {
    // Attempt to get the currently authenticated user
    GoogleSignInAccount currentUser = _googleSignIn.currentUser;
    if (currentUser == null) {
      // Attempt to sign in without user interaction
      currentUser = await _googleSignIn.signInSilently();
    }
    if (currentUser == null) {
      // Force the user to interactively sign in
      currentUser = await _googleSignIn.signIn();
    }
    final GoogleSignInAuthentication auth = await currentUser.authentication;
    // Authenticate with fire
    final FirebaseUser user = await _auth.signInWithGoogle(
      idToken: auth.idToken,
      accessToken: auth.accessToken,
    );
    assert(user != null);
    assert(!user.isAnonymous);
    return user;
  }

  Future<Null> signOutWithGoogle() async {
    // Sign out with fire
    await _auth.signOut();
    // Sign out with google
    await _googleSignIn.signOut();
  }

  @override
  void initState() {
    super.initState();

    // Listen for our auth event (on reload or start)
    // Go to our  page once logged in
    _auth.onAuthStateChanged
        .firstWhere((user) => user != null)
        .then((user) {
      Navigator.of(context).pushReplacementNamed('/todos');
    });

    // Give the navigation animations, etc, some time to finish
    new Future.delayed(new Duration(seconds: 1))
        .then((_) => signInWithGoogle());
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          new Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new CircularProgressIndicator(),
              new SizedBox(width: 20.0),
              new Text("Loading..."),
            ],
          ),
        ],
      ),
    );
  }
}
