import 'package:flutter/material.dart';
import 'auth_model.dart';

class AuthDetailPage extends StatelessWidget {

  final Auth auth;

  AuthDetailPage(this.auth);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        color: const Color(0xFF736AB7),
        constraints: new BoxConstraints.expand(),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Container(
              color: const Color(0xFF86AB7),
              constraints: new BoxConstraints(
                  minHeight: 20.0,
                  maxHeight: 60.0,
                  minWidth: 50.0,
                  maxWidth: 190.0
              ),
              child: new Column(
                children: <Widget>[
                  new Text(' Login '),
                  new TextField(
                    textAlign: TextAlign.center,
                    autofocus: true,
                  ),
                  new TextField(
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}