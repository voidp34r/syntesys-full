import 'package:flutter/material.dart';
import 'ui/home/home_page.dart';
import 'ui/auth/login/login_page.dart';
import 'ui/pre/pre_page.dart';
import 'ui/splash/splash.dart';

//part 'util/authentication.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Synt3sys',
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: new SplashPage(), // This used to be new TodoList()
      routes: <String, WidgetBuilder>{
          '/home': (BuildContext context) => new HomePage(),
          '/login': (BuildContext context) => new LoginPage(),
          '/pre': (BuildContext context) => new PrePage(),
//        '/todos': (BuildContext context) => new TodoList(),
      },
//      home: new LoginPage(),
//      routes: <String, WidgetBuilder>{
//        '/home': (_) => new HomePage(),
//        '/login': (_) => new LoginPage(),
//        '/pre': (_) => new PrePage(),
//      }
    );
  }
}


class FooPage extends StatefulWidget {
  final String title = 'FooPage';


  @override
  State createState() => new _FooPageState();
}

class _FooPageState extends State<StatefulWidget> {

  @override
  Widget build(BuildContext context) {
    return new Text('data');
  }
}
