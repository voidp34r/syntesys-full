// Copyright (c) 2018, Void P34r 
// Source Code

// import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// import 'core/core_app.dart';
import 'main/app.dart';
// import 'crypto/crypto_app.dart';
// import 'todo/todo_app.dart';

void main(){
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitDown,
    DeviceOrientation.portraitUp,
  ]);
  runApp(new SynApp());
}


// void main() => runApp(new SynApp());

// void main() async {
//   // Bad practice alert :). You should ideally show the UI, and probably a progress view,
//   // then when the requests completes, update the UI to show the data.
//   List currencies = await getCurrencies();
//   print(currencies);

//   runApp(new MaterialApp(
//     home: new Center(
//       child: new CryptoListWidget(currencies),
//     ),
//   ));
// }