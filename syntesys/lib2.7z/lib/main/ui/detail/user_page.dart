import 'package:flutter/material.dart';
import '../../model/users.dart';

class UserDetailPage extends StatelessWidget {

  final User user;

  UserDetailPage(this.user);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        color: const Color(0xFF736AB7),
        constraints: new BoxConstraints.expand(),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Text(user.name),
            new Text('teu cu doido!'),
            new Hero(tag: "planet-hero-${user.id}",
              child: new Image.asset(
                  user.image,
                  width: 96.0,
                  height: 96.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}