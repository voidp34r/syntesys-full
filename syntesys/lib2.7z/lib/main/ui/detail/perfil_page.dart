import 'package:flutter/material.dart';
import '../../model/perfil.dart';

class DetailPage extends StatelessWidget {

  final Perfil perfil;

  DetailPage(this.perfil);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Container(
        color: const Color(0xFF736AB7),
        constraints: new BoxConstraints.expand(),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            new Text(perfil.name),
            new Hero(tag: "planet-hero-${perfil.id}",
              child: new Image.asset(
                  perfil.image,
                  width: 96.0,
                  height: 96.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}