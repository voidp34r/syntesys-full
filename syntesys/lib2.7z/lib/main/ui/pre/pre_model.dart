class Pre {
  final String id;
  final String name;
  final String location;
  final String distance;
  final String gravity;
  final String description;
  final String image;

  const Pre({this.id, this.name, this.location, this.distance, this.gravity,
    this.description, this.image});
}

List<Pre> pres = [
  const Pre(
    id: "1",
    name: "Matheus Rafael",
    location: "joinville",
    distance: "54.6m Km",
    gravity: "3.711 m/s ",
    description: "CEO Synteysys",
    image: "assets/img/mars.png",
  ),
  const Pre(
    id: "2",
    name: "Voidp34r",
    location: "Florianópolis",
    distance: "54.6m Km",
    gravity: "3.711 m/s ",
    description: "DEV hacker...",
    image: "assets/img/neptune.png",
  ),
  const Pre(
    id: "3",
    name: "M4rk3r",
    location: "Plêiades",
    distance: "54.6m Km",
    gravity: "3.711 m/s ",
    description: "OrionLandy...",
    image: "assets/img/moon.png",
  ),
];