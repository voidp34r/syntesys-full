class Auth {
  final String id;
  final String name;
  final String location;
//  final String distance;
//  final String gravity;
  final String description;
  final String image;

  const Auth({
    this.id,
    this.name,
    this.location,
//    this.distance,
//    this.gravity,
    this.description, this.image});
}

List<Auth> authList = [
  const Auth(
    id: "1",
    name: "Login",
    location: "/login",
    description: " Login Lorem ipsum...",
    image: "assets/img/mars.png",
  ),
  const Auth(
    id: "2",
    name: "Register",
    location: "/register",
    description: " Register Lorem ipsum...",
    image: "assets/img/mars.png",
  ),
  const Auth(
    id: "3",
    name: "Recovery",
    location: "/recovery",
    description: " Recovery Lorem ipsum...",
    image: "assets/img/mars.png",
  ),
];