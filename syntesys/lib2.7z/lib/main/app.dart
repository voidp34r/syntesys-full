// Copyright (c) 2018, Void P34r 
// Source Code

import 'screens/auth/personal_data.dart';
import 'screens/auth/signin.dart';
import 'screens/welcome.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';

// import 'widgets/gradiente_appbar.dart';
// import 'package:flutter/material.dart';
// import 'pages/default_page.dart';
// import 'pages/demon_page.dart';
// import 'pages/home_page.dart';
// import 'pages/login_page.dart';
// import 'pages/screen_page.dart';
// import 'pages/splash_page.dart';
// import 'ui/pre/pre_page.dart';
// import 'core/core_app.dart';


class SynApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'Syntesys • Flutter',
      debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        fontFamily: 'Helvetica Neue',
        brightness: Brightness.dark,
        primaryColor: Colors.lightBlue[800],
        accentColor: Colors.cyan[600],
        primarySwatch: Colors.blueGrey,
      ),
      home: new Welcome(),
      // initialRoute: '/',
      routes: <String, WidgetBuilder>{
        "/welcome":(BuildContext context) => new Welcome(),
        "/signin": (BuildContext context) => new SignIn(),
        "/personal_data": (BuildContext context) => new PersonalData(),
        // "/activities": (BuildContext context) => new Activities(),
      },
    );
  }
}






