import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:async';
import 'package:intl/intl.dart';

class ActivityData{
  final String name;
  final String id;
  final String imageUrl;

  ActivityData(this.name, this.id, this.imageUrl);
}

class ActivitiesModel{
  CollectionReference get activities => Firestore.instance.collection('activities');
  DocumentReference get users => Firestore.instance.collection("users").document("voidp34r");
  final formatter = new DateFormat("dd MMM yyyy");

  Future<List<ActivityData>> getAllActivities() async{
    QuerySnapshot snapshot = await  activities.getDocuments();
    checkToday();
    List<ActivityData> activityList = snapshot.documents.map((document){
      return new ActivityData(document["name"], document.documentID, document["icon"]);
    }).toList();
    return activityList;
  }

  void checkToday() {
    print(checkToday);
  }
}