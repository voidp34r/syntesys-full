// Copyright (c) 2018, Void P34r 
// Source Code

import 'package:flutter/material.dart';
import '../widgets/gradiente_appbar.dart';

class DemoPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: new Column(
        children: <Widget>[
          new GradientAppBar("Syntesys"),
          // new PrePageBody(),
        ],
      ),
    );
  }
}
