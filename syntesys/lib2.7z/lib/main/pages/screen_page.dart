// Copyright (c) 2018, Void P34r 
// Source Code

import 'package:flutter/material.dart';
import '../widgets/gradiente_appbar.dart';

class Screen1 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return new Scaffold( // 1
      appBar: new AppBar(
        title: new Text("Screen 1"), // screen title

      ),
      body: new Center(
        child: new Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            GradientAppBar("Syntesys"),
            new Card(
              child: new Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const ListTile(
                    leading: const Icon(Icons.local_cafe),
                    title: const Text('The Enchanted Nightingale'),
                    subtitle: const Text('Music by Julie Gable. Lyrics by Sidney Stein.'),
                  ),
                  new ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: new ButtonBar(
                      children: <Widget>[
                        new FlatButton(
                          child: const Text('BUY TICKETS'),
                          onPressed: () { /* ... */ },
                        ),
                        new FlatButton(
                          child: const Text('LISTEN'),
                          onPressed: () { /* ... */ },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            new RaisedButton(onPressed:(){
              button1(context);
            } ,child: new Text("Go to Screen 2"),)
          ],
        ),
      ) ,
    );
  }
}


class Screen2 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return new Scaffold(
      appBar: 
      new AppBar(
        title: new Text("Screen 2"),

      ),
      body: new Center(
        child: new Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            GradientAppBar("Syntesys"),
            new RaisedButton(onPressed:(){
              button2(context);
            } ,child: new Text("Back to Screen 1"),)
          ],
        ),
      ) ,
    );

  }
}


void button1(BuildContext context){
  print("Button 1");
  Navigator.of(context).pushNamed('/screen2');
}

void button2(BuildContext context){
  print("Button 2");
  Navigator.of(context).pop(true);
}