// Copyright (c) 2018, Void P34r 
// Source Code

import 'package:flutter/material.dart';
import '../widgets/gradiente_appbar.dart';

class DefaultScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      // appBar: new AppBar(
      //   backgroundColor: Colors.greenAccent,
      // ),
      body: new Container(
        child: new Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            new GradientAppBar("Syntesys"),
            new Card(
              elevation: 2.0,
              child: new Center(
                child: new Column(
                  children: <Widget>[
                    new Text('data.id'),
                    new Text('data.name'),
                    new Text('data.username'),
                    new Text('data.email'),
                    new Text('data.telefone'),
                  ],
                ),
              )
            ),
          ],
        ),
      ) ,
    );
  }
}